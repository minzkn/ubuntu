<?php
$css_friendly=1;
$_sidebar=0;
$_topbanner=0;
$_topicon=0;
$_logo=0;
$_width='750px';
?>
