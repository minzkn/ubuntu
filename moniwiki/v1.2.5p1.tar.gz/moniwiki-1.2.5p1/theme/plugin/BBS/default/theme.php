<?php
$compat=1;
?>
