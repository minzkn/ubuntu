<?php
//
// MoniWiki PageKey class
//
// @since  2015/05/06
// @author wkpark@kldp.org
//

class PageKey_base {
    function getPageKey($pagename) {
    }

    function pageToKeyname($pagename) {
    }

    function keyToPagename($key) {
    }
}

// vim:et:sts=4:sw=4:
