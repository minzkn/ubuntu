<?
$pagename=array(
  _("FrontPage"), _("RecentChanges"), _("FindPage"), _("UserPreferences"),
  _("TitleIndex"), _("HelpContents"),
  _("DeletePage"), _("LikePages"), _("FindPage"), _("UploadFile"),
  _("UploadedFiles"), _("EditText"), _("ShowPage"), _("InterWiki"),
  _("BlogChanges"),_("VisualTour"),_("TrackBack"),
  _("source"),_("diff"), _("recall"), _("view"),
);

_("Contents");
_("last modified:");
?>
