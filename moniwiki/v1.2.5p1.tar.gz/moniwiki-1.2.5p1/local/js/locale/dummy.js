N_("Continue to edit current text ?");
N_("Canceled!");
N_("Please select the text you would like to turn into a link.");

//
N_("Auto saved text found.\nAre you sure to restore page ?\n(You can undo/redo with Ctrl-Z/Ctrl-Shift-Z)");
N_("Current text is saved in a temporary file.");

// sh
N_("The code is in your clipboard now");
N_('Printing...');
N_("copy to clipboard");
N_("view plain");
N_("Toggle line numbers");

// Toolbar
N_('Bold text');
N_('Italic text');
N_('Internal link');
N_('Link title');
N_('External link (remember http:// prefix)');
N_('http://www.example.com link title');
N_('Level 2 headline');
N_('Headline text');
N_('Mathematical formula (LaTeX)');
N_('Insert latex formula here');
N_('Ignore wiki formatting');
N_('Insert non-formatted text here');
N_('Horizontal line (use sparingly)');
N_('Embedded image');
N_('Media file link');
N_('Smiley');
N_('Your signature with timestamp');
N_('Click a button to get an example text');
N_('Please enter the text you want to be formatted.\\\\n It will be shown in the infobox for copy and pasting.\\\\nExample:\\\\n\$1\\\\nwill become:\\\\n\$2');

// etc.
N_('Contents');
N_('last modified:');
